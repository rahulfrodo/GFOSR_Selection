fosr.dense.scvs<-function(GrandY,UT,X,M,npcbas=5,pen="grMCP")
{
  n<-nrow(X)
  p1<-ncol(X)
  p2<-ncol(M)
  library(refund)
  Ymat<-matrix(GrandY,nrow=n,ncol=length(UT),byrow=TRUE)
  w.sm = fpca.face(Ymat,npc=npcbas, var=FALSE,argvals = UT,knots = 35, p = 3, m = 8) ### make var false, can choose the # of npc, pve not working pave maybe
  Ysc<- w.sm$scores
  K=ncol(Ysc)
  ###########################
  Yvec<-  as.vector(t(Ysc))
  constrmat<-function(colvec,rownum)
  {mat<-kronecker(diag(rownum),t(colvec))
  mat
  }
  Xmat<-list()
  for(i in 1:n)
  {Xmat[[i]]<-constrmat(X[i,],K)
  }
  
  GrandX<-Reduce(rbind,Xmat)
  ####M the variable of interest############
  Mmat<-list()
  for(i in 1:n)
  {Mmat[[i]]<-constrmat(M[i,],K)
  }
  GrandM<-matrix(0,nrow=length(Yvec),ncol = p2*K)
  for(i in 1:n)
  {a<-(i-1)*K+1
  b<-a+K-1
  GrandM[a:b,]<-Mmat[[i]]
  }
  
  #######################
  library(grpreg)
  GrandZ<-cbind(GrandX,GrandM)
  col1<-ncol(GrandX)
  group<-c()
  for (r in 1:(p2))
  {group[(0:(K-1))*p2+r+col1]<-r
  }  
  group[1:col1]<-0  
  Groupvar<-as.factor(group)
  fit2 <- grpreg(GrandZ,Yvec,Groupvar,penalty=pen)
  cvfit2<-select(fit2,crit="EBIC")
  gamma2<-cvfit2$beta
  indsel2<-which(gamma2[-1]!=0)
  Groupsel2<-group[indsel2]
  grind2<-unique(Groupsel2)
  varselected2<-grind2
  efmat<-w.sm$efunctions
  lambdamcp<-cvfit2$lambda
  fit23 <- grpreg(GrandZ,Yvec,Groupvar,penalty=pen,lambda = lambdamcp)
  YhatscMCP<-predict(fit23,GrandZ)
  ###################
  YMCPsc<-matrix(YhatscMCP,nrow = n,ncol=K,byrow = TRUE)
  muhat<-w.sm$mu
  mumat<-matrix(rep(muhat,n),nrow=n,byrow = TRUE)
  YhatMCP<-YMCPsc%*%t(efmat)+mumat
  nmean<-colMeans(Ymat)
  nmeanest<-matrix(rep(nmean,n),nrow=n,byrow = TRUE)
  b0<-mean((as.vector(Ymat)-as.vector(nmeanest))^2)
  a12<-mean((as.vector(Ymat)-as.vector(YhatMCP))^2)
  rsq<-1-(a12/b0) 
  result<-list(varselected2,gamma2,efmat,rsq)
  names(result)<-c("varselected2","gamma2","efmat","rsq")
  print(varselected2)
  return(result)
}