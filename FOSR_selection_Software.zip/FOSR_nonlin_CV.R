fosr.scvsCVnp<-function( GrandY,T,X,M,pen="grMCP",nbas=c(7,7))
{
  n<-nrow(X)
  p1<-ncol(X)
  p2<-ncol(M)
  npce<-nbas[1]
  nnpbas<-nbas[2]
  UT<-c()
  for( i in 1:n)
  {UT<-union(UT,T[[i]])}
  UT<-sort(UT)
  Ymat<-matrix(GrandY,nrow=n,ncol=length(UT),byrow=TRUE)
  set.seed(1)
  library(caret)
  find<-createFolds(c(1:n), k = 5, list = FALSE, returnTrain = FALSE)
  cvauc3<-c()
  for (k in 1:5)
  { tempind=which(find==k)
  Ymattr<-Ymat[-tempind,]
  Ymatte<-Ymat[tempind,]
  library(refund)
  w.sm = fpca.face(Ymattr, npc=npce, var=FALSE,argvals = UT,knots = 35, p = 3, m = 8) 
  Ysc<- w.sm$scores
  K=ncol(Ysc)
  ##########################################################
  Yvec<-  as.vector(t(Ysc))
  constrmat<-function(colvec,rownum)
  {mat<-kronecker(diag(rownum),t(colvec))
  mat
  }
  Xmat<-list()
  for(i in 1:n)
  {Xmat[[i]]<-constrmat(X[i,],K)
  }
  xmattrain<-Xmat[-tempind]
  xmattest<-Xmat[tempind]
  GrandXtr<-Reduce(rbind,xmattrain)
  GrandXte<-Reduce(rbind,xmattest)
  
  #####M2 the variable of interest continuous############
  p2<-ncol(M)
  ###SET UP P2/Q MANY BASIS SYSTEMS##############
  knots<-list()
  nbasis<-list()
  dayrng<-list()
  bbasis<-list()
  for( j in 1:p2)
  {library(fda) 
    knots[[j]] = seq( min(M[,j]),max(M[,j]),l=(nnpbas-2)) 
    norder = 4
    # this implies the number of basis functions
    nbasis[[j]] = length(knots[[j]]) + norder - 2
    dayrng[[j]] = c(min(M[,j]),max(M[,j]))
    bbasis[[j]] = create.bspline.basis(dayrng[[j]],nbasis[[j]],norder,knots[[j]])
  }
  
  ####M the variable of interest############
  Mmat<-list()
  for(i in 1:n)
  {rowvec<-c()
  for(j in 1:p2)
  {rowvec<-c(rowvec,eval.basis(M[i,j],bbasis[[j]]))}
  Mmat[[i]]<-constrmat(rowvec,K) 
  }
  
  Mmattrain<-Mmat[-tempind]
  Mmattest<-Mmat[tempind]
  GrandMtr<-Reduce(rbind,Mmattrain)
  GrandMte<-Reduce(rbind,Mmattest)
  ###################################
  library(grpreg)
  #J number of basis
  GrandZtr<-cbind(GrandXtr,GrandMtr)
  GrandZte<-cbind(GrandXte,GrandMte)
  col1<-ncol(GrandXtr)
  groupvec<-c()
  for (r in 1:(p2))
  {groupvec[(nnpbas*(r-1)+1):(nnpbas*r)]<-rep(r,nnpbas)
  }
  groupvecM<-rep(groupvec,K)
  group<-c(rep(0,col1),groupvecM)  
  Groupvar<-as.factor(group)
  ######################################################################
  fit3 <- grpreg(GrandZtr,Yvec,Groupvar,penalty="grMCP")
  cvfit3<-select(fit3,crit="EBIC")  
  gamma3<-cvfit3$beta
  indsel3<-which(gamma3[-1]!=0)
  Groupsel3<-group[indsel3]
  grind3<-unique(Groupsel3)
  varselected3<-grind3
  efmat<-w.sm$efunctions
  #######################
  lambdamcp<-cvfit3$lambda
  fit23 <- grpreg(GrandZtr,Yvec,Groupvar,penalty="grMCP",lambda = lambdamcp)
  YhatscMCPte<-predict(fit23,GrandZte)
  ts<-nrow(Ymatte)
  ###################
  YMCPscte<-matrix(YhatscMCPte,nrow = ts,ncol=K,byrow = TRUE)
  muhat<-w.sm$mu
  mumat<-matrix(rep(muhat,ts),nrow=ts,byrow = TRUE)
  YhatMCPte<-YMCPscte%*%t(efmat)+mumat
  mspe<-mean((as.vector(Ymatte)-as.vector(YhatMCPte))^2)
  cvauc3[k]<-mspe
  }
  mean(cvauc3)
}