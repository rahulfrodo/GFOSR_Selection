fosr.scvsCV<-function(Y,T,X,M,pen="grMCP",nbas=5)
{
  n<-nrow(X)
  p1<-ncol(X)
  p2<-ncol(M)
  UT<-c()
  for( i in 1:n)
  {UT<-union(UT,T[[i]])}
  UT<-sort(UT)
  GrandY<-NULL
  for(i in 1:n)
  {GrandY<-c(GrandY,Y[[i]])
  }
  Ymat<-matrix(GrandY,nrow=n,ncol=length(UT),byrow=TRUE)
  set.seed(1)
  library(caret)
  find<-createFolds(c(1:n), k = 5, list = FALSE, returnTrain = FALSE)
  cvauc3<-c()
  for (k in 1:5)
  { tempind=which(find==k)
  
  Ymattr<-Ymat[-tempind,]
  Ymatte<-Ymat[tempind,]
  library(refund)
  w.sm = fpca.face(Ymattr, npc=nbas, var=FALSE,argvals = UT,knots = 35, p = 3, m = 8) ### make var false, can choose the # of npc, pve not working pave maybe
  Ysc<- w.sm$scores
  K=ncol(Ysc)
  ###########################
  Yvec<-  as.vector(t(Ysc))
  constrmat<-function(colvec,rownum)
  {mat<-kronecker(diag(rownum),t(colvec))
  mat
  }
  Xmat<-list()
  for(i in 1:n)
  {Xmat[[i]]<-constrmat(X[i,],K)
  }
  xmattrain<-Xmat[-tempind]
  xmattest<-Xmat[tempind]
  
  GrandXtr<-Reduce(rbind,xmattrain)
  GrandXte<-Reduce(rbind,xmattest)
  
  ####M the variable of interest############
  Mmat<-list()
  for(i in 1:n)
  {Mmat[[i]]<-constrmat(M[i,],K)
  }
  
  Mmattrain<-Mmat[-tempind]
  Mmattest<-Mmat[tempind]
  GrandMtr<-Reduce(rbind,Mmattrain)
  GrandMte<-Reduce(rbind,Mmattest)
  
  #######################
  library(grpreg)
  GrandZtr<-cbind(GrandXtr,GrandMtr)
  GrandZte<-cbind(GrandXte,GrandMte)
  col1<-ncol(GrandXtr)
  group<-c()
  for (r in 1:(p2))
  {group[(0:(K-1))*p2+r+col1]<-r
  }  
  group[1:col1]<-0  
  Groupvar<-as.factor(group)
  fit2 <- grpreg(GrandZtr,Yvec,Groupvar,penalty=pen)
  cvfit2<-select(fit2,crit="EBIC")
  gamma2<-cvfit2$beta
  indsel2<-which(gamma2[-1]!=0)
  Groupsel2<-group[indsel2]
  grind2<-unique(Groupsel2)
  varselected2<-grind2
  lambdamcp<-cvfit2$lambda
  fit23 <- grpreg(GrandZtr,Yvec,Groupvar,penalty="grMCP",lambda = lambdamcp)
  YhatscMCPte<-predict(fit23,GrandZte)
  ts<-nrow(Ymatte)
  YMCPscte<-matrix(YhatscMCPte,nrow = ts,ncol=K,byrow = TRUE)
  muhat<-w.sm$mu
  efmat<-w.sm$efunctions
  mumat<-matrix(rep(muhat,ts),nrow=ts,byrow = TRUE)
  YhatMCPte<-YMCPscte%*%t(efmat)+mumat
  mspe<-mean((as.vector(Ymatte)-as.vector(YhatMCPte))^2)
  cvauc3[k]<-mspe
  }
  mean(cvauc3)
}
