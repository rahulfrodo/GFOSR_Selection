# FOSR_lin_CV, FOSR_lin_Select, FOSR_nonlin_CV, FOSR_nonlin_Select scripts contains the main functions and needs to be sourced 
#######################################################################
See "FLCM_selection.html" for toy illustration in simulated data.

Currently implementation support data on dense regular grid.
#######################################################################

# The following wrapper functions are used for variable selection in linear FOSR
########################################################################
# Function for cross-validation
# fosr.scvsCV(Y,T,X,M,pen = "grMCP",nbas =5)
########################################################################
@ GrandY: Stacked response vector
@ UT: time grid
@ X,M: The scalar covariate matrix (centered)
@ nbas: Number of fpc basis to use
########################################################################
# Function for variable selection in linear FOSR
# fosr.dense.scvs(GrandY,UT,X,M,npcbas=7,pen="grMCP")
########################################################################
@ GrandY: Stacked response vector
@ UT: time grid
@ X,M: The scalar covariate matrix (centered)
@ npcbas: Number of basis to use, supply the cross-validated number of basis
#####################################################################################
# The following wrapper functions are used for variable selection in nonlinear FOSR
#####################################################################################
# Function for cross-validation
# fosr.scvsCVnp(GrandY = GrandY,T=T,X=X,M=M,nbas=c(7,7))
#####################################################################################
@ GrandY: Stacked response vector
@ T: list T[[i]] which are grid and same for dense data
@ X,M: The scalar covariate matrix (X is centered)
@ nbas: Number of basis to use, 
@ nbas[1] : number of npc basis  
@ nbas[2] : number of B-splines basis
########################################################################
# Function for variable selection in nonlinear FOSR
# fosr.dense.nlvs(GrandY,T,X,M,pen = "grMCP",nbas=c(7,7))
########################################################################
@ GrandY: Stacked response vector
@ T: list T[[i]] which are grid and same for dense data
@ X,M: The scalar covariate matrix (X is centered)
@ nbas: Number of basis to use, 
@ nbas[1] : number of npc basis  
@ nbas[2] : number of B-splines basis



